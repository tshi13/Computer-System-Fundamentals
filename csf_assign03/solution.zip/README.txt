Ian Zheng yzheng67
Taiming Shi tshi13

MS1
Ian: Makefile
Taiming: main.cpp

MS2
Ian: majority of cache functionality
Taiming: parse_line, finish up debugging