# CSF
Taiming Shi: tshi13
Ian Zheng: yzheng67

Taiming:
fixedpoint_create
fixedpoint_create2
fixedpoint_whole_part
fixedpoint_frac_part
fixedpoint_is_zero

Ian:
TEST(test_create_all_IntObjs);
TEST(test_create2_all_FracObjs);
TEST(test_is_zero);
TEST(test_is_zero_uninitialized);